import React from 'react'

const MobileNav = () => {
  return (
    <div>
      
    </div>
  )
}

export default MobileNav
